<?php

class Services_Twilio_Rest_Pricing_MessagingCountry
    extends Services_Twilio_PricingInstanceResource {
}
