<?php

class Services_Twilio_Rest_IPMessaging_User extends Services_Twilio_IPMessagingInstanceResource {

}
